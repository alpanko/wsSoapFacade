package it.dsgroup.enel.wsSoapFacade;

public class TransferService {
	
	public void pippo() {
		System.out.println("Pippo");
	}

}
